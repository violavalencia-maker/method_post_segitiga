<?php
require_once "Segitiga.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $alas = $_POST['alas'];
    $tinggi = $_POST['tinggi'];

    $segitiga = new Segitiga($alas, $tinggi);

    $luas = $segitiga->hitungLuas();
    $keliling = $segitiga->hitungKeliling();
} else {
    echo "<p>Data tidak dikirim melalui method POST!</p>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hasil Perhitungan Segitiga</title>
</head>
<body>
    <h2>Hasil Perhitungan Segitiga Siku-siku</h2>
    <p>Alas: <?= $alas ?></p>
    <p>Tinggi: <?= $tinggi ?></p>
    <p>Luas: <?= number_format($luas, 2) ?></p>
    <p>Keliling: <?= number_format($keliling, 2) ?></p>
    <br>
    <a href="plain_form.html">Kembali ke Form</a>
</body>
</html>