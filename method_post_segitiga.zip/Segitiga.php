<?php
class Segitiga {
    private $alas;
    private $tinggi;

    public function __construct($alas, $tinggi) {
        $this->alas = $alas;
        $this->tinggi = $tinggi;
    }

    public function hitungLuas() {
        return 0.5 * $this->alas * $this->tinggi;
    }

    public function hitungKeliling() {
        $miring = sqrt(($this->alas ** 2) + ($this->tinggi ** 2)); // Pythagoras
        return $this->alas + $this->tinggi + $miring;
    }
}
?>